# VanGuard Windows10/11 x64

Buka MODUL_PENGGUNAAN_VANGUARD.html; Bab10 untuk instalasi dan Bab11–12 untuk endpoint.
Manual ini berasal dari satu sumber resmi repository. Hasil native ada pada checkpoint.
