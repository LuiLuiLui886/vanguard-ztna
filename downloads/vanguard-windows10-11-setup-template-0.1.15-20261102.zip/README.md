# VanGuard Windows10/11 x64

Paket per-device: jalankan Setup-VanGuard.bat untuk instalasi/config/enrollment terpandu.
Jika provision.json belum tersedia, admin perlu membangun paket per-device dahulu.
Buka MODUL_PENGGUNAAN_VANGUARD.html; Bagian1–4 untuk instalasi sampai connect, Bagian7 untuk paket per-device dan Bagian8 untuk internet terkelola.
Manual ini berasal dari satu sumber resmi repository. Hasil native ada pada checkpoint.
